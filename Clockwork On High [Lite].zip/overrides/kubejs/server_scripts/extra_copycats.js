ServerEvents.recipes(event => {

    event.stonecutting(
        Item.of('extra_copycats:copycat_collapsible', 8),
        'create:zinc_ingot'
    )

    event.stonecutting(
        Item.of('extra_copycats:copycat_collapsible_grid', 8),
        'create:zinc_ingot'
    )

    event.stonecutting(
        Item.of('extra_copycats:copycat_cabinet_door', 4),
        'create:zinc_ingot'
    )
})