PlayerEvents.loggedIn(event => {
    const player = event.player

if (!player.tags.contains("intro_done")) {
    player.tell(Text.aqua("Welcome to Clockwork On High!").bold())
    player.tell(Text.gray("Open your guide book with ").append(Text.gold("J").bold()))
}})